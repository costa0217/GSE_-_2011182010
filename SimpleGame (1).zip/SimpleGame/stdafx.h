#pragma once

#include "targetver.h"

#include <stdio.h>
#include <tchar.h>

#include <iostream>
#include <map>
#include <vector>
#include <list>
#include <algorithm>
#include <time.h>

using namespace std;

